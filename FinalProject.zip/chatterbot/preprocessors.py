
def clean_whitespace(chatbot, statement):

    statement.text = statement.text.replace('\n', ' ').replace('\r', ' ').replace('\t', ' ')

    statement.text = statement.text.strip()


    return statement

