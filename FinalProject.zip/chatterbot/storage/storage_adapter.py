import logging


class StorageAdapter(object):

    def __init__(self, base_query=None, *args, **kwargs):
        self.kwargs = kwargs
        self.logger = kwargs.get('logger', logging.getLogger(__name__))
        self.adapter_supports_queries = True
        self.base_query = None

    def get_model(self, model_name):
        # The string must be lowercase
        model_name = model_name.lower()

        kwarg_model_key = '%s_model' % (model_name,)

        if kwarg_model_key in self.kwargs:
            return self.kwargs.get(kwarg_model_key)

        get_model_method = getattr(self, 'get_%s_model' % (model_name,))

        return get_model_method()

    def generate_base_query(self, chatterbot, session_id):
        if self.adapter_supports_queries:
            for filter_instance in chatterbot.filters:
                self.base_query = filter_instance.filter_selection(chatterbot, session_id)

    def count(self):
        raise self.AdapterMethodNotImplementedError(
            'The `count` method is not implemented by this adapter.'
        )

    def find(self, statement_text):
        raise self.AdapterMethodNotImplementedError()

    def remove(self, statement_text):
        raise self.AdapterMethodNotImplementedError()

    def filter(self, **kwargs):
        raise self.AdapterMethodNotImplementedError(
        )

    def update(self, statement):
        raise self.AdapterMethodNotImplementedError(
        )

    def get_latest_response(self, conversation_id):
        raise self.AdapterMethodNotImplementedError(
        )

    def create_conversation(self):
        raise self.AdapterMethodNotImplementedError(
        )

    def add_to_conversation(self, conversation_id, statement, response):
        raise self.AdapterMethodNotImplementedError(
        )

    def get_random(self):
        raise self.AdapterMethodNotImplementedError(
        )

    def drop(self):
        raise self.AdapterMethodNotImplementedError(
        )

    def get_response_statements(self):
        statement_list = self.filter()

        responses = set()
        to_remove = list()
        for statement in statement_list:
            for response in statement.in_response_to:
                responses.add(response.text)
        for statement in statement_list:
            if statement.text not in responses:
                to_remove.append(statement)

        for statement in to_remove:
            statement_list.remove(statement)

        return statement_list

    class EmptyDatabaseException(Exception):

        def __init__(self, value='The database currently contains no entries. At least one entry is expected. You may need to train your chat bot to populate your database.'):
            self.value = value

        def __str__(self):
            return repr(self.value)

    class AdapterMethodNotImplementedError(NotImplementedError):
        pass
