from .chatterbot import ChatBot
import logging
__all__ = (
    'ChatBot',
    logging.basicConfig(filename='myapp.log', level=logging.INFO)
)
