import logging


class Adapter(object):

    def __init__(self, **kwargs):
        self.logger = kwargs.get('logger', logging.getLogger(__name__))
        self.chatbot = kwargs.get('chatbot')

    def set_chatbot(self, chatbot):
        self.chatbot = chatbot

    class AdapterMethodNotImplementedError(NotImplementedError):
        def __init__(self, message=None):
            if not message:
                message = ' '
            self.message = message

        def __str__(self):
            return self.message

    class InvalidAdapterTypeException(Exception):
        pass
