from __future__ import unicode_literals
from .output_adapter import OutputAdapter


class TerminalAdapter(OutputAdapter):
    def process_response(self, statement, session_id=None):
        print(statement.text)
        return statement.text
