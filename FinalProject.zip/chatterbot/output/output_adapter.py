from chatterbot.adapters import Adapter


class OutputAdapter(Adapter):

    def process_response(self, statement, session_id=None):
        return statement
