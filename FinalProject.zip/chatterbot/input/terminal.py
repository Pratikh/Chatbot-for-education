from __future__ import unicode_literals
from chatterbot.input import InputAdapter
from chatterbot.conversation import Statement
from chatterbot.utils import input_function


class TerminalAdapter(InputAdapter):

    def process_input(self, *args, **kwargs):
        user_input = input_function()
        return Statement(user_input)
