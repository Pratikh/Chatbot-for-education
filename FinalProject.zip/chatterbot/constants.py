
STATEMENT_TEXT_MAX_LENGTH = 400

# The maximum length of characters that the name of a tag can contain
TAG_NAME_MAX_LENGTH = 50
