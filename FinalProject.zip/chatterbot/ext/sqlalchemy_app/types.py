from sqlalchemy.types import TypeDecorator, Unicode


class UnicodeString(TypeDecorator):

    impl = Unicode

    def process_bind_param(self, value, dialect):
        import sys

        if sys.version_info[0] < 3:
            if isinstance(value, str):
                value = value.decode('utf-8')
        return value
