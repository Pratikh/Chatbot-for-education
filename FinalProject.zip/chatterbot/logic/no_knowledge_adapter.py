from __future__ import unicode_literals
from .logic_adapter import LogicAdapter


class NoKnowledgeAdapter(LogicAdapter):
    def process(self, statement):
        if self.chatbot.storage.count():
            statement.confidence = 0
        else:
            statement.confidence = 1

        return statement
