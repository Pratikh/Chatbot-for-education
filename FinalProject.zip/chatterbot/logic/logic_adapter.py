from __future__ import unicode_literals
from chatterbot.adapters import Adapter
from chatterbot.utils import import_module


class LogicAdapter(Adapter):
    def __init__(self, **kwargs):
        super(LogicAdapter, self).__init__(**kwargs)
        from chatterbot.comparisons import levenshtein_distance
        from chatterbot.response_selection import get_first_response

        # Import string module parameters
        if 'statement_comparison_function' in kwargs:
            import_path = kwargs.get('statement_comparison_function')
            if isinstance(import_path, str):
                kwargs['statement_comparison_function'] = import_module(import_path)

        if 'response_selection_method' in kwargs:
            import_path = kwargs.get('response_selection_method')
            if isinstance(import_path, str):
                kwargs['response_selection_method'] = import_module(import_path)

        # By default, compare statements using Levenshtein distance
        self.compare_statements = kwargs.get(
            'statement_comparison_function',
            levenshtein_distance
        )

        # By default, select the first available response
        self.select_response = kwargs.get(
            'response_selection_method',
            get_first_response
        )

    def get_initialization_functions(self):
        return self.compare_statements.get_initialization_functions()

    def initialize(self):
        for function in self.get_initialization_functions().values():
            function()

    def can_process(self, statement):
        return True

    def process(self, statement):
        raise self.AdapterMethodNotImplementedError()

    @property
    def class_name(self):
        return str(self.__class__.__name__)

    class EmptyDatasetException(Exception):

        def __init__(self, value='An empty set was received when at least one statement was expected.'):
            self.value = value

        def __str__(self):
            return repr(self.value)
