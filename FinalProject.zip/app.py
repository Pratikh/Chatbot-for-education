from flask import Flask, render_template, request
from chatterbot import ChatBot

from chatterbot.trainers import ListTrainer
import os

app = Flask(__name__)
english_bot = ChatBot('Test')

english_bot.set_trainer(ListTrainer)

for files in os.listdir('files1'):
    chats = open('files1/' + files , 'r').readlines()

    english_bot.train(chats)


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/index.html")
def home1():
    return render_template("index.html")


@app.route("/about.html")
def about():
    return render_template("about.html") 


@app.route("/contact.html")
def contact():
    return render_template("contact.html")


@app.route("/courses.html")
def courses():
    return render_template("courses.html")    


@app.route("/events.html")
def event():
    return render_template("events.html")


@app.route("/gallery.html")
def gallery():
    return render_template("gallery.html")


@app.route("/get")
def get_bot_response():
    userText = request.args.get('msg')
    while True:
        if userText.strip() != 'bye':
            return str(english_bot.get_response(userText))

        if userText.strip() == 'bye':
            return str("Bye.. Have good day..")
        break 


if __name__ == "__main__":
    app.run(host='0.0.0.0',debug=True,port=8888)
